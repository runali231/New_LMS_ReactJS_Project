
import LoginForm from "./loginForm";

const index = () => {
  return (
    <LoginForm />
    
  );
};

export default index;