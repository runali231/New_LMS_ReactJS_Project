
const UrlData = "https://localhost:44355/api/";
// const UrlData = "https://tmsback.initialinfinity.com/api/"

// const UrlData = "http://tmsback/api/";
// const UrlData = "http://lmspublish:803/api/"
// const UrlData = "http://lmsbackend.rensatubes.com/api/";
// const UrlData = "http://lmsbackend.rensatubes.com:4000/api/"
// const UrlData = "http://visualpublish.local/api/"


export default UrlData;

