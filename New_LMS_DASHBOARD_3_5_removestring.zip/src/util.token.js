// utils/token.js
let tokenValue = "";

export const setToken = (token) => {
  tokenValue = token;
};

export const getToken = () => {
  return tokenValue;
};


// utils/token.js
let idValue = "";

export const setId = (id) => {
  idValue = id;
};

export const getId = () => {
  return idValue;
};